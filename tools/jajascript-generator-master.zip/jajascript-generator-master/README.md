## JajaScript Trip Generator

	coffee jajascript-generator.coffee [iteration]

will generate `iteration * 5` overlapping random trips for jajascript
